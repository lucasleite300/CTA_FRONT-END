import React from 'react'
import Routes from './Routes'

const App = props =>(
    <>
        <div id='app'>
            <Routes />
        </div>
    </>
     
)
export default App