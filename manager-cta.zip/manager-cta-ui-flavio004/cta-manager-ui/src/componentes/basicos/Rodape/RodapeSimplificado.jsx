import React from 'react'
import '../Rodape/rodape.css'

const RodapeSimplificado = (props) =>{
    return(
        
    <footer className="container-flex text-center">       
        <div className="p-3">
        <small><strong>Desenvolvido pela Equipe Engenharia de Computação - UEMA</strong><br/><strong>São Luis/MA - 2021</strong></small>
        </div>
    </footer>
    )
}
export default RodapeSimplificado